## NPC Avatar Icon Mod (Temporary Verson) 0.4.0
by Eudemonism00 2024/1/3


### Instructions
Sorry for my poor English. I used machine translation.

After installing the social will have small avatars of characters. The expression follows the attitude text changes, some characters have different genders or styling difference.
I don't know how to code, I wrote the mod myself. There may be bugs that I haven't checked for.
In the future, I may ask others to help make a formal version...

This mod is just my fanart. The game does not give the specific appearance of characters, please do not mistake it for the official appearance.
The mod (including images and code) can be used freely within the scope of DoL, and can be changed or integrated; if you want to make a similar function, it's fine, you don't need to ask me!
If you want to change or integrate it, please make sure to keep the "Image Instructions" part, or mark it somewhere else in the game.


（安装后社交栏会有角色小头像，表情跟随态度文本变化，部分角色有不同性别或造型的差分
本人不会代码，自己乱写的mod，标准是能用就行，问题很大，未来可能会请别人帮忙做个正式版

游戏并未给出角色的具体样貌，头像为本模组的二次创作，请不要将其误认为是官方形象
模组（包括图片和代码）在DoL相关范围内自由使用，可二改二转；如果你想做一个类似功能也没问题，不需要问我
如果要二改或整合，请务必保留“图像说明”部分，或者在游戏内其他地方标注）


### Contact me
Tieba: Eudemonism00
Email: halcyon7643@qq.com
Discord: vitamins77#8804 (You can find me in DoL modding server.)


### I have completed the following
- Alex（24 pictures）
- Remy（14 pictures）
- Gwylan（1 picture）
- Wren（14 pictures）
- Bailey（2 pictures）
- Jordan（3 pictures）
- Sydney（112 pictures）
- Harper（7 pictures）
- Whitney（26 pictures）
- Landry（4 pictures）
- Kylar（28 pictures）
- Darryl（12 pictures）
- Briar（10 pictures）